<footer style="bottom: 0; width: 100%;">
<section class="section-freelancer">
	  <div class="align-center pad-30 bg-white">
	  	 <ul>
	  	 	 <li>Encontre Freelancers</li>
	  	 	 <li>Trabalhos Freelancers</li>
	  	 	 <li>Contratar Freelancers</li>
	  	 </ul>
	  </div>
</section>

<section class="bg-blue pad-30">

	<div class="container align-center">
		
		<div class="total_f">
			<div class="total-item">
			    <h3>530.897</h3>  
			      <h4>Freelancers</h4>
		  </div>
		
			<div class="total-item">
					<h3>530.897</h3>  
					  <h4>Total de projetos publicados</h4>
		  </div>   
		  
		  <div class="total-item">
					<h3>530.897</h3>  
					  <h4>Usuários cadastrados</h4>
			</div>		  
		</div>

		<div class="total-btn">
			<a href="#" class="btn-2">Crie um projeto</a>
			<a href="#" class="btn-2">Trabalhe como um Freelancer</a>
		</div>

	
	</div>
</section>

<section class="bg-footer">
  <div class="container-footer">
			<div class="free-footer">
			  <h6>Doutor Site | Todos os direitos reservados © <?php $date = date('Y'); echo $date ?></h6>
		  </div>
		<div class="social">
			<ul>
				<li><a href="#" class="imagem-svg">
					<span class="icon-facebook"></span></a></li>
				<li><a href="#" class="imagem-svg">
					<span class="icon-twitter"></span></a></li>
				<li><a href="#" class="imagem-svg">
					<span class="icon-linkedin2"></span></a></li>
			</ul>
		</div>
	</div>
 </section>	
</footer> 


<script src="assets/js/jquery-3.1.1.min.js" type="text/javascript"></script>
<script src="//ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js"></script>
<script> WebFont.load({
	      google: {
	        families: [
	          'Open+Sans+Condensed:300',
	          'Open+Sans:300,400,600',
	          'Roboto:700'
	      ]
	    }
	  });
</script>
<script src="assets/js/app.js" type="text/javascript" async></script>
</body>
</html>