<?php  
require 'pages/page.php';
