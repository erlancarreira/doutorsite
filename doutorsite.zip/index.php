<?php 
$x = 'index';

$p = $x;
if(isset($_GET['p']) && !empty($_GET['p']) && file_exists('pages/'.$_GET['p'].'.php')) {
	$p = $_GET['p'];
}

if(file_exists('cache/'.$p.'.cache')) {
	require 'cache/'.$p.'.cache';
} else {


ob_start();
require 'classes/usuarios.class.php';
$u = new Usuarios();

/*$total_usuarios = $u->getTotalUsuarios(); */ 

require 'pages/header.php';

require 'pages/'.$p.'.php';  
              
require 'pages/footer.php'; 

$html = ob_get_contents();
ob_end_clean();



file_put_contents('cache/'.$p.'.cache', $html);
echo $html;
}

?>