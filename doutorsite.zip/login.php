<?php require 'pages/header.php';  ?>            

<section class="container">

<div class="container-login">

<h2>Login</h2>
<form method="POST" class="form-login">	
	<div class="form-campos">
			<input class="place" type="text" name="nome" placeholder="Nome de usuário" >
  </div>
  <div class="form-campos">    
      <input class="place" type="text" name="senha" placeholder="Senha">
  </div> 
	
	<div class="lembrar-s">
    <label>Lembrar senha:</label>
    <input type="checkbox" name="save">
    <a href="#">
      Esqueceu a senha?
      </a>

    </div>
<div class="btn-lg">   
  <input type="submit" value="Entrar">
</div>
<div class="btn-lg">
  <a href="cadastre-se.php">Cadastre-se </a> 
</div> 

  </div>

</form>

</div>
</section>
<?php require 'pages/footer.php'; ?>
