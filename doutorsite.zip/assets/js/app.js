/* 
    $(document).ready(function() {
    

  $('.cad').click(function(e){
    e.preventDefault();
    $('.cadastro').toggleClass('active');
    $('.login').removeClass('active');
});    
    $('.log').click(function(e){
    e.preventDefault();
    $('.login').toggleClass('active');
    $('.cadastro').removeClass('active');    
   
  });

 
});
*/
$(function(){   
var fixed = $('header');   
$(window).scroll(function () { 
if ($(this).scrollTop() > 100) { 
fixed.addClass("header-fix"); 
} else { 
fixed.removeClass("header-fix"); 
} 
});  
});

function myFunction(x) {
    x.classList.toggle("change");
    $('.ativo').toggleClass('active');
}           
    // Alternative animation for example
    // slideToggle("fast");
 
 $(document).ready(function(){       
            var num = 0;
            $(window).on('scroll', function() { 
             
                if ($(this).scrollTop() > 100 ) {
                    $(".header").addClass('bg-white').removeClass('bg-drsite');
                } else {
                    $(".header").removeClass('bg-white');
                }
                 if ($(this).scrollTop() > 100 ) {
                    $(".bg-bar").addClass('bg-barsite').removeClass('bg-white');
                } else {
                    $(".bg-bar").removeClass('bg-barsite');

                }
                if ($(this).scrollTop() > 100 ) {
                    $("a.ativo").addClass('acolor');
                } else {
                    $("a.ativo").removeClass('acolor');

                }
                if ($(this).scrollTop() > 100 ) {
                    $(".logo").attr("src", "assets/img/dr-site-logo-aescuro.png");
                } else {
                    $(".logo").attr("src", "assets/img/dr-site-logo.png");

                }
            });
        }); 

    $('header').each(function() {
        var height = $(this).height(),
        offsetTop = $(this).offset().top;

    });
